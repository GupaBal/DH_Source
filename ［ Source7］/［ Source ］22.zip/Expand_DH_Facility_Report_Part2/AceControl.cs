﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Apros_Class_Library_Base;
using DevComponents.DotNetBar.Controls;
using DH_Facility_Report_Part2.Properties;
using ChartFX.WinForms.Gauge;
using DevComponents.DotNetBar;
using System.IO;
using System.Threading;

namespace DH_Facility_Report_Part2
{
    #region [ # Data Structure ]
    ///=============================================================================================================///
    /// <summary>                                                                         [ Ver 1.00 / 20XX-XX-XX ] ///
    /// ▷ Section_Info ◁                                                                                          ///
    /// 
    /// </summary>
    ///=============================================================================================================///
    public struct Section_Info
    {
        public string Section_Num;
        public string Station_Start;
        public double Station_Sval;
        public string Station_End;
        public double Station_Eval;
    }

    ///=============================================================================================================///
    /// <summary>                                                                         [ Ver 1.00 / 20XX-XX-XX ] ///
    /// ▷ Facility_Info ◁                                                                                         ///
    /// 
    /// </summary>
    ///=============================================================================================================///
    public struct Facility_Info
    {
        public string Facility_Num;
        public string Facility_Name;
        public List<Section_Info> Sections_Tunnel;
        public List<Section_Info> Sections_Lining;
    }

    ///=============================================================================================================///
    /// <summary>                                                                         [ Ver 1.00 / 20XX-XX-XX ] ///
    /// ▷ Workbook_Info ◁                                                                                         ///
    /// 
    /// </summary>
    ///=============================================================================================================///
    #region [ # Workbook_Info ]
    public struct Workbook_Info
    {
        public string File_Name;
        public string Processing;
        public string Completion_Date;
        public string Facility_Address;
        public string Facility_Type;
        public string Diagnosis_Type;
        public string Diagnosis_Company;
        public string Diagnosis_Price;
        public string Diagnosis_Start_Date;
        public string Diagnosis_End_Date;
        public string Parts_Level1;
        public string Parts_Level2;
        public string Facility_Grade;
        public string Facility_Defect;
    }
    #endregion

    ///=============================================================================================================///
    /// <summary>                                                                         [ Ver 1.00 / 20XX-XX-XX ] ///
    /// ▷ Sheet_Info ◁                                                                                            ///
    /// 
    /// </summary>
    ///=============================================================================================================///
    #region [ # Sheet_Info ]
    public struct Sheet_Info
    {
        public string Sheet_Name;
        public string Processing;
        public string Data_Index;
        public string Parts_Level3;
        public string Parts_Level4;
        public string Parts_Level5;
        public string Parts_Level6;
        public string Performance_Improve;
        public string Parts_Grade;
        public string Parts_Defect;
        public string Facility_Grade;
        public string Facility_Defect;
        public string Damage_Type;
        public string Damage_Points;
        public string Damage_Picture;
        public string Maintenance_Plan;
        public string Maintenance_Method;
        public string Maintenance_Quantity;
        public string Maintenance_Quantity_Unit;
        public string Maintenance_Unit_Price;
        public string Maintenance_Cost;
        public string Remarks;
    }
    #endregion

    ///=============================================================================================================///
    /// <summary>                                                                         [ Ver 1.00 / 20XX-XX-XX ] ///
    /// ▷ Data_File_Info ◁                                                                                        ///
    /// 
    /// </summary>
    ///=============================================================================================================///
    #region [ # Data_File_Info ]
    public struct Data_File_Info
    {
        public Workbook_Info Workbook;
        public List<Sheet_Info> Sheets;
    }
    #endregion

    ///=============================================================================================================///
    /// <summary>                                                                         [ Ver 1.00 / 20XX-XX-XX ] ///
    /// ▷ Data_File_List ◁                                                                                        ///
    /// 
    /// </summary>
    ///=============================================================================================================///
    #region
    public struct Data_File_List
    {
        public string Report_Name;
        public List<Data_File_Info> Files;
    }
    #endregion

    ///=============================================================================================================///
    /// <summary>                                                                         [ Ver 1.00 / 20XX-XX-XX ] ///
    /// ▷ Data_Index ◁                                                                                            ///
    /// 
    /// </summary>
    ///=============================================================================================================///
    #region [ # Data_Index ]
    public struct Data_Index
    {
        public List<List<int>> row;
        public List<List<int>> col;
    }
    #endregion

    ///=============================================================================================================///
    /// <summary>                                                                         [ Ver 1.00 / 20XX-XX-XX ] ///
    /// ▷ Report_Data ◁                                                                                           ///
    /// 
    /// </summary>
    ///=============================================================================================================///
    #region [ # Report_Data ]
    public struct Report_Data
    {
        public string Facility_Number;
        public string Facility_Name;
        public string Manage_Number;
        public string Completion_Date;
        public string Facility_Address;
        public string Facility_Type;
        public string Diagnosis_Type;
        public string Diagnosis_Company;
        public string Diagnosis_Price;
        public string Diagnosis_Start_Date;
        public string Diagnosis_End_Date;
        public string Parts_Level1;
        public string Parts_Level2;
        public string Parts_Level3;
        public string Parts_Level4;
        public string Parts_Level5;
        public string Parts_Level6;
        public string Performance_Improve;
        public string Parts_Grade;
        public string Parts_Defect;
        public string Facility_Grade;
        public string Facility_Defect;
        public string Damage_Type;
        public string Damage_Points;
        public string Damage_Picture;
        public string Maintenance_Plan;
        public string Maintenance_Method;
        public string Maintenance_Quantity;
        public string Maintenance_Quantity_Unit;
        public string Maintenance_Unit_Price;
        public string Maintenance_Cost;
        public string Remarks;
    }
    #endregion
    #endregion

    ///=============================================================================================================///
    /// <summary>                                                                         [ Ver 1.00 / 20XX-XX-XX ] ///
    /// ▷ AceControl: UserControl ◁                                                                               ///
    ///     소프트웨어에서 사용되는 모든 이벤트 핸들러를 구현한다.                                                  ///
    ///                                                                                                             ///
    /// [ Ver 1.00 / 20XX-XX-XX ]                                                                                   ///
    ///     ▶ 초기버전                                                                                             ///
    /// </summary>                                                                                                  ///
    ///=============================================================================================================///
    public partial class AceControl: UserControl
    {
        #region [ # Defines & Variables ]
        // 버전 정보 상수
        private readonly string Version = "Expand DH_Facility_Report_Part2 - Ver 1.00.00.xxxx";

        private readonly string DataPath = CommonBase.DataPath;
        private readonly string Configpath = CommonBase.ConfigPath;

        // 델리게이트 함수
        private delegate void setTextBoxText(TextBoxX tb, string msg);
        private delegate void setPanelBackgroundImage(Panel p, Image img);
        private delegate void setLabelText(LabelX l, string msg);
        private delegate void setSwitchButton(SwitchButton sb, bool set);

        //
        private StringBuilder sb;

        // 초기화 수행 여부
        private bool Init_State = true;

        // 
        private List<Facility_Info> Facilities = new List<Facility_Info>();

        // 
        private string ConfigFile = string.Empty;
        private List<Data_File_List> Data_Source = new List<Data_File_List>();

        //
        private Dictionary<string, int> Indexer = new Dictionary<string, int>();
        #endregion

        #region [ # Constructor & Initializer ]
        ///=========================================================================================================///
        /// <summary>                                                                     [ Ver 1.00 / 20XX-XX-XX ] ///
        /// @ AceControl @                                                                                          ///
        ///     생성자로 컨트롤을 초기화한다.                                                                       ///
        /// </summary>                                                                                              ///
        ///=========================================================================================================///
        public AceControl()
        {
            InitializeComponent();
        }

        ///=========================================================================================================///
        /// <summary>                                                                     [ Ver 1.00 / 20XX-XX-XX ] ///
        /// @ AceControl_Load @                                                                                     ///
        ///     폼이 로드되는 시점에 호출되며 다항식 라벨의 값을 설정한다.                                          ///
        /// </summary>                                                                                              ///
        /// <param name="sender"> object : 이벤트 발생 객체 </param>                                                ///
        /// <param name="e"> EventArgs : 이벤트 관련 정보 </param>                                                  ///
        ///=========================================================================================================///
        private void AceControl_Load(object sender, EventArgs e)
        {
            label_version.Text = Version;

            sb = new StringBuilder();

            Indexer.Add("A", 1);   Indexer.Add("B", 2);   Indexer.Add("C", 3);   Indexer.Add("D", 4);   Indexer.Add("E", 5);
            Indexer.Add("F", 6);   Indexer.Add("G", 7);   Indexer.Add("H", 8);   Indexer.Add("I", 9);   Indexer.Add("J", 10);
            Indexer.Add("K", 11);  Indexer.Add("L", 12);  Indexer.Add("M", 13);  Indexer.Add("N", 14);  Indexer.Add("O", 15);
            Indexer.Add("P", 16);  Indexer.Add("Q", 17);  Indexer.Add("R", 18);  Indexer.Add("S", 19);  Indexer.Add("T", 20);
            Indexer.Add("U", 21);  Indexer.Add("V", 22);  Indexer.Add("W", 23);  Indexer.Add("X", 24);  Indexer.Add("Y", 25);
            Indexer.Add("Z", 26);  Indexer.Add("AA", 27); Indexer.Add("AB", 28); Indexer.Add("AC", 29); Indexer.Add("AD", 30);
            Indexer.Add("AE", 31); Indexer.Add("AF", 32); Indexer.Add("AG", 33); Indexer.Add("AH", 34); Indexer.Add("AI", 35);
            Indexer.Add("AJ", 36); Indexer.Add("AK", 37); Indexer.Add("AL", 38); Indexer.Add("AM", 39); Indexer.Add("AN", 40);
            Indexer.Add("AO", 41); Indexer.Add("AP", 42); Indexer.Add("AQ", 43); Indexer.Add("AR", 44); Indexer.Add("AS", 45);
            Indexer.Add("AT", 46); Indexer.Add("AU", 47); Indexer.Add("AV", 48); Indexer.Add("AW", 49); Indexer.Add("AX", 50);
            Indexer.Add("AY", 51); Indexer.Add("AZ", 52);
        }
        #endregion

        #region [ # Delegate Functions ]
        ///=========================================================================================================///
        /// <summary>                                                                     [ Ver 1.00 / 20XX-XX-XX ] ///
        /// @ SetTextBoxText @                                                                                      ///
        ///     매개변수로 지정한 텍스트박스에 메시지를 설정한다.                                                   ///
        /// </summary>                                                                                              ///
        /// <param name="tb"> TextBoxX : 대상 객체 </param>                                                         ///
        /// <param name="msg"> string : 메시지 </param>                                                             ///
        ///=========================================================================================================///
        private void SetTextBoxText(TextBoxX tb, string msg)
        {
            if (tb.InvokeRequired == true)
            {
                tb.Invoke(new setTextBoxText(SetTextBoxText), tb, msg);
            }
            else
            {
                tb.Text = msg;
            }
        }

        ///=========================================================================================================///
        /// <summary>                                                                     [ Ver 1.00 / 20XX-XX-XX ] ///
        /// @ SetPanelBackgroundImage @                                                                             ///
        ///     매개변수로 지정한 패널의 배경 이미지를 설정한다.                                                    ///
        /// </summary>                                                                                              ///
        /// <param name="p"> Panel : 대상 객체 </param>                                                             ///
        /// <param name="img"> Image : 설정 이미지 </param>                                                         ///
        ///=========================================================================================================///
        private void SetPanelBackgroundImage(Panel p, Image img)
        {
            if (p.InvokeRequired == true)
            {
                p.Invoke(new setPanelBackgroundImage(SetPanelBackgroundImage), p, img);
            }
            else
            {
                p.BackgroundImage = img;
            }
        }

        ///=========================================================================================================///
        /// <summary>                                                                     [ Ver 1.00 / 20XX-XX-XX ] ///
        /// @ SetLabelText @                                                                                        ///
        ///     매개변수로 지정하 라벨에 값을 설정한다.                                                             ///
        /// </summary>                                                                                              ///
        /// <param name="l"> LabelX : 대상 객체 </param>                                                            ///
        /// <param name="msg"> string : 설정 값 </param>                                                            ///
        ///=========================================================================================================///
        private void SetLabelText(LabelX l, string msg)
        {
            if(l.InvokeRequired==true)
            {
                l.Invoke(new setLabelText(SetLabelText), l, msg);
            }
            else
            {
                l.Text = msg;
            }
        }

        ///=========================================================================================================///
        /// <summary>                                                                     [ Ver 1.00 / 20XX-XX-XX ] ///
        /// @ SetSwitchButton @                                                                                     ///
        ///     매개변수로 지정한 스위치버튼의 값을 설정한다.                                                       ///
        /// </summary>                                                                                              ///
        /// <param name="sb"> SwitchButton : 대상 객체 </param>                                                     ///
        /// <param name="set"> bool : 설정 값 </param>                                                              ///
        ///=========================================================================================================///
        private void SetSwitchButton(SwitchButton sb, bool set)
        {
            if (sb.InvokeRequired == true)
            {
                sb.Invoke(new setSwitchButton(SetSwitchButton), sb, set);
            }
            else
            {
                sb.Value = set;
            }
        }
        #endregion

        #region [ # Ver 1.00 ]
        #region [ # Timer Handler ]
        ///=========================================================================================================///
        /// <summary>                                                                     [ Ver 1.00 / 20XX-XX-XX ] ///
        /// @ timer_status_Tick @                                                                                   ///
        ///     통신 상태를 주기적으로 확인하여 화면에 표출한다.                                                    ///
        /// </summary>                                                                                              ///
        /// <param name="sender"> object : 이벤트 발생 객체 </param>                                                ///
        /// <param name="e"> EventArgs : 이벤트 관련 정보 </param>                                                  ///
        ///=========================================================================================================///
        private void timer_status_Tick(object sender, EventArgs e)
        {
            if ((DateTime.Now.Second % 2) == 0)
            {

            }
            else
            {

            }
        }
        #endregion

        #region [ # Event Handler ]
        ///=========================================================================================================///
        /// <summary>                                                                     [ Ver 1.00 / 20XX-XX-XX ] ///
        /// @ m_btn_Init_Click @                                                                                    ///
        ///     초기화 작업을 수행한다.                                                                             ///
        /// </summary>                                                                                              ///
        /// <param name="sender"> object : 이벤트 발생 객체 </param>                                                ///
        /// <param name="e"> EventArgs : 이벤트 관련 정보 </param>                                                  ///
        ///=========================================================================================================///
        private void m_btn_Init_Click(object sender, EventArgs e)
        {

        }

        ///=========================================================================================================///
        /// <summary>                                                                     [ Ver 1.00 / 20XX-XX-XX ] ///
        /// @ m_btn_log_clear_Click @                                                                               ///
        ///     통신 로그 창의 내용을 초기화한다.                                                                   ///
        /// </summary>                                                                                              ///
        /// <param name="sender"> object : 이벤트 발생 객체 </param>                                                ///
        /// <param name="e"> EventArgs : 이벤트 관련 정보 </param>                                                  ///
        ///=========================================================================================================///
        private void m_btn_log_clear_Click(object sender, EventArgs e)
        {
            m_txb_comm_logs.Text = string.Empty;
            m_txb_comm_raws.Text = string.Empty;
        }

        ///=========================================================================================================///
        /// <summary>                                                                     [ Ver 1.00 / 20XX-XX-XX ] ///
        /// @ AceControl_VisibleChanged @                                                                           ///
        ///     패널의 표시 상태 변경 시 초기화 이벤트를 호출한다.                                                  ///
        ///     (초기 1회만 수행)                                                                                   ///
        /// </summary>                                                                                              ///
        /// <param name="sender"> object : 이벤트 발생 객체 </param>                                                ///
        /// <param name="e"> EventArgs : 이벤트 관련 정보 </param>                                                  ///
        ///=========================================================================================================///
        private void AceControl_VisibleChanged(object sender, EventArgs e)
        {
            if (Init_State == true)
            {
                m_btn_Init_Click(sender, e);
                Init_State = false;
                tabControl1.SelectedTabIndex = 0;
            }
        }

        #region [ # Tunnel Data ]
        ///=========================================================================================================///
        /// <summary>                                                                     [ Ver 1.00 / 20XX-XX-XX ] ///
        /// @ m_btn_Tunnel_Button_Click @                                                                           ///
        ///     버튼 클릭 시 해당 기능을 수행한다.                                                                  ///    
        ///                                                                                                         ///
        ///     ▶ m_btn_TData_Path      : 처리할 데이터 파일의 경로를 지정한다.                                    ///
        ///     ▶ m_btn_Proc_Tunnel     : 터널 데이터를 처리하여 진단 보고서를 생성한다.                           ///
        ///     ▶ m_btn_sel_infoFacT    : 시설물 기본 정보를 불러와 정보 리스트를 생성한다.                        ///
        ///     ▶ m_btn_sel_infoSecL    : 터널의 상세정보(본선라이닝)를 불러온다.                                  ///
        ///     ▶ m_btn_sel_infoSecT    : 터널의 상세정보(개착터널)를 불러온다.                                    ///
        ///     ▶ m_btn_sel_formTunn    : 진단 보고서 양식을 지정한다.                                             ///
        /// </summary>                                                                                              ///
        /// <param name="sender"> object : 이벤트 발생 객체 </param>                                                ///
        /// <param name="e"> EventArgs : 이벤트 관련 정보 </param>                                                  ///
        ///=========================================================================================================///
        private void m_btn_Tunnel_Button_Click(object sender, EventArgs e)
        {
            #region [ # m_btn_TData_Path ]
            if (sender == m_btn_TData_Path)
            {
                using (FolderBrowserDialog fbd = new FolderBrowserDialog())
                {
                    fbd.SelectedPath = Application.StartupPath;

                    if (fbd.ShowDialog() == DialogResult.OK)
                    {
                        SetTextBoxText(m_txb_TuData_Path, fbd.SelectedPath);
                    }
                }
            }
            #endregion
            #region [ # m_btn_sel_formTunn ]
            else if (sender == m_btn_sel_formTunn)
            {
                using (FolderBrowserDialog fbd = new FolderBrowserDialog())
                {
                    fbd.SelectedPath = Application.StartupPath;

                    if (fbd.ShowDialog() == DialogResult.OK)
                    {
                        SetTextBoxText(m_txb_path_TuReport, fbd.SelectedPath);
                    }
                }
            }
            #endregion
            #region [ # m_btn_Proc_Tunnel ]
            else if (sender == m_btn_Proc_Tunnel)
            {
                ProcessData(true);
                /*
                DirectoryInfo di = new DirectoryInfo(m_txb_TuData_Path.Text);
                DirectoryInfo[] dirs = di.GetDirectories();
                FileInfo[] dfiles = new FileInfo[0];
                
                if (dirs.Length > 0)
                {
                    foreach (DirectoryInfo dir in dirs)
                    {
                        dfiles = dir.GetFiles();
                    }
                }
                else
                {
                    dfiles = di.GetFiles();
                }

                if (dfiles.Length > 0)
                {
                    Report_Manager rm_data = new Report_Manager();

                    foreach (FileInfo file in dfiles)
                    {
                        if (file.Name.Contains("라이닝결함지수") == true)
                        {
                            rm_data.Init_Excel_Report(file.FullName, "Page 1");
                            int num = 1;

                            while (rm_data.Existing_Sheet("Page " + num) == true)
                            {
                                object[,] data = rm_data.GetData();
                                int row = data.GetLength(0);
                                int col = data.GetLength(1);

                                for (int r = 0; r < row; r++)
                                {
                                    for (int c = 0; c < col; c++)
                                    {

                                    }
                                }

                                num++;
                            }

                            rm_data.CloseExcel();
                        }
                        else if (file.Name.Contains("리스트") == true)
                        {

                        }
                    }
                }*/
            }
            #endregion
            else
            {
                using (OpenFileDialog ofd = new OpenFileDialog())
                {
                    ofd.InitialDirectory = CommonBase.DataPath;

                    if (ofd.ShowDialog() == DialogResult.OK)
                    {
                        FileInfo fi;
                        Report_Manager rm = new Report_Manager();

                        #region [ # m_btn_sel_infoFacT ]
                        if (sender == m_btn_sel_infoFacT)
                        {
                            SetTextBoxText(m_txb_path_TuFac, ofd.FileName);
                            fi = new FileInfo(m_txb_path_TuFac.Text);

                            rm.Init_Excel_Report(fi.FullName, "상세제원정보");
                            object[,] data = rm.GetData();
                            int row = data.GetLength(0);
                            int col = data.GetLength(1);
                            rm.CloseExcel();

                            if (Facilities.Count > 0)
                            {
                                Facilities.Clear();
                            }

                            for (int i = 2; i < (row + 1); i++)
                            {
                                if (data[i, 1] != null)
                                {
                                    Facility_Info faci = new Facility_Info();
                                    faci.Facility_Num = data[i, 1].ToString();
                                    faci.Facility_Name = data[i, 2].ToString();
                                    faci.Sections_Tunnel = new List<Section_Info>();
                                    faci.Sections_Lining = new List<Section_Info>();

                                    Facilities.Add(faci);
                                }
                                else
                                {
                                    break;
                                }
                            }

                            MessageBox.Show("상세제원(공통) 로드 완료");
                        }
                        #endregion
                        #region [ # m_btn_sel_infoSecL ]
                        else if (sender == m_btn_sel_infoSecL)
                        {
                            SetTextBoxText(m_txb_path_Section_Line, ofd.FileName);
                            fi = new FileInfo(m_txb_path_TuFac.Text);

                            rm.Init_Excel_Report(fi.FullName, "상세제원정보");
                            object[,] data = rm.GetData();
                            rm.CloseExcel();

                            string f_num = string.Empty;
                            List<Section_Info> SI = new List<Section_Info>();

                            foreach (object[] tmp in data)
                            {
                                if (string.IsNullOrEmpty(f_num) == true)
                                {
                                    f_num = tmp[0].ToString();
                                }
                                else
                                {
                                    if (f_num.Equals(tmp[0].ToString()) == true)
                                    {
                                        Section_Info seci  = new Section_Info();
                                        seci.Section_Num   = tmp[1].ToString();
                                        seci.Station_Start = tmp[3].ToString();
                                        seci.Station_End   = tmp[4].ToString();

                                        string[] sub = seci.Station_Start.Split(new char[] { ')', 'K' }, StringSplitOptions.RemoveEmptyEntries);
                                        seci.Station_Sval = Convert.ToInt32(sub[1]) * 1000 + Convert.ToDouble(sub[2]);

                                        sub = seci.Station_End.Split(new char[] { ')', 'K' }, StringSplitOptions.RemoveEmptyEntries);
                                        seci.Station_Eval = Convert.ToInt32(sub[1]) * 1000 + Convert.ToDouble(sub[2]);

                                        SI.Add(seci);
                                    }
                                }
                            }

                            foreach (Facility_Info faci in Facilities)
                            {
                                if (faci.Facility_Num.Equals(f_num) == true)
                                {
                                    Facility_Info new_one = new Facility_Info();
                                    new_one.Facility_Name = faci.Facility_Name;
                                    new_one.Facility_Num = faci.Facility_Num;

                                    if (new_one.Sections_Lining.Count > 0)
                                    {
                                        new_one.Sections_Lining.Clear();
                                    }

                                    new_one.Sections_Lining = SI;

                                    int idx = Facilities.IndexOf(faci);
                                    Facilities[idx] = new_one;
                                }
                            }
                        }
                        #endregion
                        #region [ # m_btn_sel_infoSecT ]
                        else if (sender == m_btn_sel_infoSecT)
                        {
                            SetTextBoxText(m_txb_path_Section_Tunnel, ofd.FileName);
                            fi = new FileInfo(m_txb_path_TuFac.Text);

                            rm.Init_Excel_Report(fi.FullName, "상세제원정보");
                            object[,] data = rm.GetData();
                            rm.CloseExcel();

                            string f_num = string.Empty;
                            List<Section_Info> SI = new List<Section_Info>();

                            foreach (object[] tmp in data)
                            {
                                if (string.IsNullOrEmpty(f_num) == true)
                                {
                                    f_num = tmp[0].ToString();
                                }
                                else
                                {
                                    if (f_num.Equals(tmp[0].ToString()) == true)
                                    {
                                        Section_Info seci = new Section_Info();
                                        seci.Section_Num = tmp[1].ToString();
                                        seci.Station_Start = tmp[3].ToString();
                                        seci.Station_End = tmp[4].ToString();

                                        string[] sub = seci.Station_Start.Split(new char[] { ')', 'K' }, StringSplitOptions.RemoveEmptyEntries);
                                        seci.Station_Sval = Convert.ToInt32(sub[1]) * 1000 + Convert.ToDouble(sub[2]);

                                        sub = seci.Station_End.Split(new char[] { ')', 'K' }, StringSplitOptions.RemoveEmptyEntries);
                                        seci.Station_Eval = Convert.ToInt32(sub[1]) * 1000 + Convert.ToDouble(sub[2]);

                                        SI.Add(seci);
                                    }
                                }
                            }

                            foreach (Facility_Info faci in Facilities)
                            {
                                if (faci.Facility_Num.Equals(f_num) == true)
                                {
                                    Facility_Info new_one = new Facility_Info();
                                    new_one.Facility_Name = faci.Facility_Name;
                                    new_one.Facility_Num = faci.Facility_Num;

                                    if (new_one.Sections_Tunnel.Count > 0)
                                    {
                                        new_one.Sections_Tunnel.Clear();
                                    }

                                    new_one.Sections_Tunnel = SI;

                                    int idx = Facilities.IndexOf(faci);
                                    Facilities[idx] = new_one;
                                }
                            }
                        }
                        #endregion
                    }
                }
            }
        }
        #endregion
        #endregion

        #region [ # ETC ]
        ///=========================================================================================================///
        /// <summary>                                                                     [ Ver 1.00 / 20XX-XX-XX ] ///
        /// @ Load_FileInfos @                                                                                      ///
        ///     처리 대상 데이터 파일의 정보 리스트를 구성한다.                                                     ///
        /// </summary>                                                                                              ///
        /// <param name="path"> string : 파일 정보 정의 파일 </param>                                               ///
        ///=========================================================================================================///
        private void Load_FileInfos(string path)
        {
            StreamReader sr = new StreamReader(path);
            Data_File_List one = new Data_File_List();
            int cnt = 0;

            while (sr.EndOfStream == false)
            {
                string line = sr.ReadLine(); cnt++;
                string[] sub = line == null ? new string[0] : line.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);

                if (sub.Length > 0)
                {
                    if (sub[0].Equals("[Report]") == true)
                    {
                        line = sr.ReadLine(); cnt++;
                        sub = line == null ? new string[0] : line.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);

                        if (string.IsNullOrEmpty(one.Report_Name) == false)
                        {
                            Data_Source.Add(one);
                            one = new Data_File_List();
                        }

                        one.Report_Name = sub[0];
                        one.Files = new List<Data_File_Info>();

                        line = sr.ReadLine(); cnt++;
                    }
                    else if (sub[0].Equals("[Data_List]") == true)                   // [Data_List]
                    {
                        line = sr.ReadLine(); cnt++;
                        sub = line == null ? new string[0] : line.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);

                        Data_File_Info dfi = new Data_File_Info();
                        dfi.Workbook = new Workbook_Info();
                        dfi.Workbook.Processing             = "L";                   // 데이터 파일 종류
                        dfi.Workbook.File_Name              = sub[0];                // 파일명
                        dfi.Workbook.Completion_Date        = sub[1];                // 준공일자
                        dfi.Workbook.Facility_Address       = sub[2];                // 주소
                        dfi.Workbook.Facility_Type          = sub[3];                // 종별
                        dfi.Workbook.Diagnosis_Type         = sub[4];                // 점검진단종류
                        dfi.Workbook.Diagnosis_Company      = sub[5];                // 용역업체
                        dfi.Workbook.Diagnosis_Price        = sub[6];                // 용역금액
                        dfi.Workbook.Diagnosis_Start_Date   = sub[7];                // 시작일자
                        dfi.Workbook.Diagnosis_End_Date     = sub[8];                // 종료일자
                        dfi.Workbook.Parts_Level1           = sub[9];                // 부재1
                        dfi.Workbook.Parts_Level2           = sub[10];               // 부재2

                        if (sub.Length >= 13)
                        {
                            dfi.Workbook.Facility_Grade     = sub[11];               // 시설물등급
                            dfi.Workbook.Facility_Defect    = sub[12];               // 지수
                        }

                        dfi.Sheets = new List<Sheet_Info>();

                        while (true)
                        {
                            Sheet_Info si = new Sheet_Info();

                            line = sr.ReadLine(); cnt++;
                            sub = line == null ? new string[0] : line.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);

                            if (sub.Length == 0)
                            {
                                break;
                            }
                            else
                            {
                                si.Sheet_Name                   = sub[0];           // 시트명
                                si.Processing                   = sub[1];           // 타입
                                si.Data_Index                   = sub[2];           // Data시점
                                si.Parts_Level3                 = sub[3];           // 부재3
                                si.Parts_Level4                 = sub[4];           // 부재4
                                si.Parts_Level5                 = sub[5];           // 부재5
                                si.Parts_Level6                 = sub[6];           // 부재6
                                si.Performance_Improve          = sub[7];           // 성능개선
                                si.Parts_Grade                  = sub[8];           // 부재등급
                                si.Parts_Defect                 = sub[9];           // 지수
                                si.Damage_Type                  = sub[10];          // 손상종류
                                si.Damage_Points                = sub[11];          // 손상수
                                si.Damage_Picture               = sub[12];          // 사진
                                si.Maintenance_Plan             = sub[13];          // 유지보수안
                                si.Maintenance_Method           = sub[14];          // 공법
                                si.Maintenance_Quantity         = sub[15];          // 물량
                                si.Maintenance_Quantity_Unit    = sub[16];          // 단위
                                si.Maintenance_Unit_Price       = sub[17];          // 단가
                                si.Maintenance_Cost             = sub[18];          // 공사비
                                si.Remarks                      = sub[19];          // 비고
                            }

                            dfi.Sheets.Add(si);
                        }

                        one.Files.Add(dfi);
                    }
                    else if (sub[0].Equals("[Data_Grade]") == true)                 // [Data_Grade]
                    {
                        line = sr.ReadLine(); cnt++;
                        sub = line == null ? new string[0] : line.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);

                        Data_File_Info dfi = new Data_File_Info();
                        dfi.Workbook = new Workbook_Info();
                        dfi.Workbook.File_Name                  = sub[0];           // 파일명
                        dfi.Workbook.Processing                 = "G";              // 데이터 파일 종류
                        dfi.Workbook.Completion_Date            = sub[1];           // 준공일자
                        dfi.Workbook.Facility_Address           = sub[2];           // 주소
                        dfi.Workbook.Facility_Type              = sub[3];           // 종별
                        dfi.Workbook.Diagnosis_Type             = sub[4];           // 점검진단종류
                        dfi.Workbook.Diagnosis_Company          = sub[5];           // 용역업체
                        dfi.Workbook.Diagnosis_Price            = sub[6];           // 용역금액
                        dfi.Workbook.Diagnosis_Start_Date       = sub[7];           // 시작일자
                        dfi.Workbook.Diagnosis_End_Date         = sub[8];           // 종료일자
                        dfi.Workbook.Parts_Level1               = sub[9];           // 부재1
                        dfi.Workbook.Parts_Level2               = sub[10];          // 부재2

                        dfi.Sheets = new List<Sheet_Info>();

                        while (true)
                        {
                            Sheet_Info si = new Sheet_Info();

                            line = sr.ReadLine(); cnt++;
                            sub = line == null ? new string[0] : line.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);

                            if (sub.Length == 0)
                            {
                                break;
                            }
                            else
                            {
                                si.Sheet_Name                   = sub[0];           // 시트명
                                si.Processing                   = sub[1];           // 타입
                                si.Data_Index                   = sub[2];           // Data시점
                                si.Parts_Level3                 = sub[3];           // 부재3
                                si.Parts_Level4                 = sub[4];           // 부재4
                                si.Parts_Level5                 = sub[5];           // 부재5
                                si.Parts_Level6                 = sub[6];           // 부재6
                                si.Performance_Improve          = sub[7];           // 성능개선
                                si.Parts_Grade                  = sub[8];           // 부재등급
                                si.Parts_Defect                 = sub[9];           // 지수
                                si.Facility_Grade               = sub[10];          // 시설물등급
                                si.Facility_Defect              = sub[11];          // 지수
                                si.Damage_Type                  = sub[12];          // 손상종류
                                si.Damage_Points                = sub[13];          // 손상수
                                si.Damage_Picture               = sub[14];          // 사진
                                si.Maintenance_Plan             = sub[15];          // 유지보수안
                                si.Maintenance_Method           = sub[16];          // 공법
                                si.Maintenance_Quantity         = sub[17];          // 물량
                                si.Maintenance_Quantity_Unit    = sub[18];          // 단위
                                si.Maintenance_Unit_Price       = sub[19];          // 단가
                                si.Maintenance_Cost             = sub[20];          // 공사비
                                si.Remarks                      = sub[21];          // 비고
                            }

                            dfi.Sheets.Add(si);
                        }

                        one.Files.Add(dfi);
                    }
                }
            }

            sr.Close();
            MessageBox.Show("데이터 기초 정보 로드 완료");
        }

        ///=========================================================================================================///
        /// <summary>                                                                     [ Ver 1.00 / 20XX-XX-XX ] ///
        /// @ ProcessData @                                                                                         ///
        ///     
        /// </summary>                                                                                              ///
        /// <param name="mode"> bool : 데이터 처리 모드 </param>                                                    ///
        ///=========================================================================================================///
        private void ProcessData(bool mode)
        {
            DateTime startT = DateTime.Now, endT;

            foreach (Data_File_List dfl in Data_Source)
            {
                StringBuilder DCnts = new StringBuilder();
                DCnts.AppendLine("[ " + dfl.Report_Name + " ]");

                Facility_Info fi = Find_Facility(dfl.Report_Name);
                string fac_number     = fi.Facility_Num;
                string fac_name       = fi.Facility_Name;
                string manage_num     = fac_name.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries)[0].Replace("-", "");
                string completion_day = string.Empty;
                string fac_address    = string.Empty;
                string fac_type       = string.Empty;
                string diag_type      = string.Empty;
                string diag_company   = string.Empty;
                string diag_cost      = string.Empty;
                string diag_sday      = string.Empty;
                string diag_eday      = string.Empty;
                string part_lv1       = string.Empty;
                string part_lv2       = string.Empty;
                string fac_grade      = string.Empty;
                string fac_defect     = string.Empty;

                List<Report_Data> Reports = new List<Report_Data>();

                int done = 0;
                startT = DateTime.Now;

                foreach (Data_File_Info dfi in dfl.Files)
                {
                    int sheet_cnt = dfi.Sheets.Count;

                    if (sheet_cnt > 0)
                    {
                        string dfolder = dfl.Report_Name.Split(new char[] { '_' }, StringSplitOptions.RemoveEmptyEntries)[0];
                        string file_path = @"F:\［Data Files］\" + dfolder + @"\" + dfi.Workbook.File_Name;

                        bool roop_Mode = false;
                        int roop_Page = 1;
                        string sheet_name = string.Empty;

                        Report_Manager data_file = new Report_Manager();

                        if (dfi.Sheets[0].Sheet_Name.Equals("Page 1~N") == true)
                        {
                            data_file.Init_Excel_Report(file_path, "Page 1");
                        }
                        else
                        {
                            data_file.Init_Excel_Report(file_path, dfi.Sheets[0].Sheet_Name);
                        }

                        foreach (Sheet_Info si in dfi.Sheets)
                        {
                            if (si.Sheet_Name.Equals("Page 1~N") == true)
                            {
                                roop_Mode = true;
                                sheet_name = "Page " + roop_Page;
                            }
                            else
                            {
                                roop_Mode = false;
                                sheet_name = si.Sheet_Name;
                            }

                            if (Reports.Count > 0)
                            {
                                Reports.Clear();
                            }

                            while (data_file.Change_Worksheet(sheet_name) == true)
                            {
                                object[,] raw_data = data_file.GetData();
                                int row = raw_data.GetLength(0);
                                int col = raw_data.GetLength(1);

                                if (dfi.Workbook.Processing.Equals("L") == true)
                                {
                                    if (si.Processing.Equals("A") == true)
                                    {
                                        #region [ # Procssing - List / Type A ]

                                        #endregion
                                    }
                                    else if (si.Processing.Equals("B") == true)
                                    {
                                        #region [ # Procssing - List / Type B ]
                                        List<Data_Index> indexes = Search_Index("L", si);

                                        for (int i = Convert.ToInt32(si.Data_Index); i < (row + 1); i++)
                                        {
                                            if ((raw_data[i, 1] != null) || (raw_data[i, 4] != null))
                                            {
                                                Report_Data Report = new Report_Data();
                                                Report.Facility_Number = fac_number;
                                                Report.Facility_Name = fac_name;
                                                Report.Manage_Number = manage_num;
                                                Report.Completion_Date = dfi.Workbook.Completion_Date == null ? "-" : dfi.Workbook.Completion_Date;
                                                Report.Facility_Address = dfi.Workbook.Facility_Address == null ? "-" : dfi.Workbook.Facility_Address;
                                                Report.Facility_Type = dfi.Workbook.Facility_Type == null ? "-" : dfi.Workbook.Facility_Type;
                                                Report.Diagnosis_Type = dfi.Workbook.Diagnosis_Type == null ? "-" : dfi.Workbook.Diagnosis_Type;
                                                Report.Diagnosis_Company = dfi.Workbook.Diagnosis_Company == null ? "-" : dfi.Workbook.Diagnosis_Company;
                                                Report.Diagnosis_Price = dfi.Workbook.Diagnosis_Price == null ? "-" : dfi.Workbook.Diagnosis_Price;
                                                Report.Diagnosis_Start_Date = dfi.Workbook.Diagnosis_Start_Date == null ? "-" : dfi.Workbook.Diagnosis_Start_Date;
                                                Report.Diagnosis_End_Date = dfi.Workbook.Diagnosis_End_Date == null ? "-" : dfi.Workbook.Diagnosis_End_Date;
                                                Report.Parts_Level1 = dfi.Workbook.Parts_Level1 == null ? "-" : dfi.Workbook.Parts_Level1;
                                                Report.Parts_Level2 = dfi.Workbook.Parts_Level2 == null ? "-" : dfi.Workbook.Parts_Level2;
                                                Report.Facility_Grade = dfi.Workbook.Facility_Grade == null ? si.Facility_Grade : dfi.Workbook.Facility_Grade;
                                                Report.Facility_Defect = dfi.Workbook.Facility_Defect == null ? si.Facility_Defect : dfi.Workbook.Facility_Defect;

                                                completion_day = Report.Completion_Date;
                                                fac_address = Report.Facility_Address;
                                                fac_type = Report.Facility_Type;
                                                diag_type = Report.Diagnosis_Type;
                                                diag_company = Report.Diagnosis_Company;
                                                diag_cost = Report.Diagnosis_Price;
                                                diag_sday = Report.Diagnosis_Start_Date;
                                                diag_eday = Report.Diagnosis_End_Date;
                                                fac_grade = Report.Facility_Grade;
                                                fac_defect = Report.Facility_Defect;

                                                List<string> Items = new List<string>();
                                                Items.Add(Report.Parts_Level3);
                                                Items.Add(Report.Parts_Level4);
                                                Items.Add(Report.Parts_Level5);
                                                Items.Add(Report.Parts_Level6);
                                                Items.Add(Report.Performance_Improve);
                                                Items.Add(Report.Parts_Grade);
                                                Items.Add(Report.Parts_Defect);
                                                Items.Add(Report.Damage_Type);
                                                Items.Add(Report.Damage_Points);
                                                Items.Add(Report.Damage_Picture);
                                                Items.Add(Report.Maintenance_Plan);
                                                Items.Add(Report.Maintenance_Method);
                                                Items.Add(Report.Maintenance_Quantity);
                                                Items.Add(Report.Maintenance_Quantity_Unit);
                                                Items.Add(Report.Maintenance_Unit_Price);
                                                Items.Add(Report.Maintenance_Cost);
                                                Items.Add(Report.Remarks);

                                                object value = null;

                                                for (int j = 0; j < Items.Count; j++)
                                                {
                                                    value = null;

                                                    if (j != 8)
                                                    {
                                                        int cnt = 0;

                                                        foreach (List<int> tcol in indexes[j].col)
                                                        {
                                                            foreach (int inner in tcol)
                                                            {
                                                                if (value == null)
                                                                {
                                                                    value = raw_data[i, inner] == null ? null : raw_data[i, inner].ToString();
                                                                }
                                                                else
                                                                {
                                                                    if (inner == 3)
                                                                    {
                                                                        value += value != null ? "~" : null;
                                                                    }

                                                                    value += raw_data[i, inner] == null ? "" : raw_data[i, inner].ToString();
                                                                }
                                                            }

                                                            cnt++;

                                                            if (cnt < indexes[j].col.Count)
                                                            {
                                                                value += value != null ? " " : null;
                                                            }
                                                        }

                                                        string result = value == null ? "-" : value.ToString();

                                                        switch (j)
                                                        {
                                                            case 0: Report.Parts_Level3 = result; break;
                                                            case 1: Report.Parts_Level4 = result; break;
                                                            case 2: Report.Parts_Level5 = result; break;
                                                            case 3: Report.Parts_Level6 = result; break;
                                                            case 4: Report.Performance_Improve = result; break;
                                                            case 5: Report.Parts_Grade = result; break;
                                                            case 6: Report.Parts_Defect = result; break;
                                                            case 7: Report.Damage_Type = result; break;
                                                            case 9: Report.Damage_Picture = result; break;
                                                            case 10: Report.Maintenance_Plan = result; break;
                                                            case 11: Report.Maintenance_Method = result; break;
                                                            case 12: Report.Maintenance_Quantity = result; break;
                                                            case 13: Report.Maintenance_Quantity_Unit = result; break;
                                                            case 14: Report.Maintenance_Unit_Price = result; break;
                                                            case 15: Report.Maintenance_Cost = result; break;
                                                            case 16: Report.Remarks = result; break;
                                                            default: break;
                                                        }
                                                    }
                                                }

                                                value = null;
                                                int[] columns;

                                                if (indexes[8].col.Count > 0)
                                                {
                                                    for (int k = 0; k < indexes[8].col.Count; k++)
                                                    {
                                                        columns = indexes[8].col[k].ToArray();
                                                        string result = string.Empty;
                                                        bool or_mode = false;

                                                        for (int j = 0; j < columns.Length; j++)
                                                        {
                                                            int cidx = columns[j];

                                                            if (cidx == -1)
                                                            {
                                                                or_mode = true;
                                                            }
                                                            else
                                                            {
                                                                value = raw_data[i, cidx];

                                                                if ((value != null) && (value.ToString().Equals("-") == false) && (value.ToString().Equals("0") == false))
                                                                {
                                                                    if (or_mode == false)
                                                                    {
                                                                        if (string.IsNullOrEmpty(result) == false)
                                                                        {
                                                                            result += " x ";
                                                                        }

                                                                        result += value.ToString();
                                                                    }
                                                                    else
                                                                    {
                                                                        if (string.IsNullOrEmpty(result) == true)
                                                                        {
                                                                            result += value.ToString();
                                                                        }
                                                                        else
                                                                        {
                                                                            result += " x " + value.ToString();
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }

                                                        if (string.IsNullOrEmpty(result) == true)
                                                        {
                                                            Report.Damage_Points = "-";
                                                        }
                                                        else
                                                        {
                                                            Report.Damage_Points = result;

                                                            Reports.Add(Report);
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                        #endregion
                                    }
                                }
                                else if (dfi.Workbook.Processing.Equals("G") == true)
                                {
                                    if (si.Processing.Equals("A") == true)
                                    {
                                        #region [ # Procssing - Grade / Type A ]
                                        for (int i = 3; i < (row + 1); i++)
                                        {
                                            if (raw_data[i, 1] != null)
                                            {
                                                Report_Data Report = new Report_Data();
                                                Report.Facility_Number = fac_number;
                                                Report.Facility_Name = fac_name;
                                                Report.Manage_Number = manage_num;
                                                Report.Facility_Grade = ((si.Facility_Grade == null) || (si.Facility_Grade.Equals("-"))) ? "-" : si.Facility_Grade;
                                                Report.Facility_Defect = ((si.Facility_Defect == null) || (si.Facility_Defect.Equals("-"))) ? "-" : si.Facility_Defect;

                                                #region [ # Facility Information Checking - From ex Liet Processing ]
                                                string tmp_str = dfi.Workbook.Completion_Date;

                                                if (tmp_str.Equals("-") == true)
                                                {
                                                    Report.Completion_Date = ((string.IsNullOrEmpty(completion_day) == false) && (completion_day.Equals("-") == false)) ? completion_day : tmp_str;
                                                }
                                                else
                                                {
                                                    Report.Completion_Date = (string.IsNullOrEmpty(tmp_str) == false) ? tmp_str : "-";
                                                }

                                                tmp_str = dfi.Workbook.Facility_Address;

                                                if (tmp_str.Equals("-") == true)
                                                {
                                                    Report.Facility_Address = ((string.IsNullOrEmpty(fac_address) == false) && (fac_address.Equals("-") == false)) ? fac_address : tmp_str;
                                                }
                                                else
                                                {
                                                    Report.Facility_Address = (string.IsNullOrEmpty(tmp_str) == false) ? tmp_str : "-";
                                                }

                                                tmp_str = dfi.Workbook.Facility_Type;

                                                if (tmp_str.Equals("-") == true)
                                                {
                                                    Report.Facility_Type = ((string.IsNullOrEmpty(fac_type) == false) && (fac_type.Equals("-") == false)) ? fac_type : tmp_str;
                                                }
                                                else
                                                {
                                                    Report.Facility_Type = (string.IsNullOrEmpty(tmp_str) == false) ? tmp_str : "-";
                                                }

                                                tmp_str = dfi.Workbook.Diagnosis_Type;

                                                if (tmp_str.Equals("-") == true)
                                                {
                                                    Report.Diagnosis_Type = ((string.IsNullOrEmpty(diag_type) == false) && (diag_type.Equals("-") == false)) ? diag_type : tmp_str;
                                                }
                                                else
                                                {
                                                    Report.Diagnosis_Type = (string.IsNullOrEmpty(tmp_str) == false) ? tmp_str : "-";
                                                }

                                                tmp_str = dfi.Workbook.Diagnosis_Company;

                                                if (tmp_str.Equals("-") == true)
                                                {
                                                    Report.Diagnosis_Company = ((string.IsNullOrEmpty(diag_company) == false) && (diag_company.Equals("-") == false)) ? diag_company : tmp_str;
                                                }
                                                else
                                                {
                                                    Report.Diagnosis_Company = (string.IsNullOrEmpty(tmp_str) == false) ? tmp_str : "-";
                                                }

                                                tmp_str = dfi.Workbook.Diagnosis_Price;

                                                if (tmp_str.Equals("-") == true)
                                                {
                                                    Report.Diagnosis_Price = ((string.IsNullOrEmpty(diag_cost) == false) && (diag_cost.Equals("-") == false)) ? diag_cost : tmp_str;
                                                }
                                                else
                                                {
                                                    Report.Diagnosis_Price = (string.IsNullOrEmpty(tmp_str) == false) ? tmp_str : "-";
                                                }

                                                tmp_str = dfi.Workbook.Diagnosis_Start_Date;

                                                if (tmp_str.Equals("-") == true)
                                                {
                                                    Report.Diagnosis_Start_Date = ((string.IsNullOrEmpty(diag_sday) == false) && (diag_sday.Equals("-") == false)) ? diag_sday : tmp_str;
                                                }
                                                else
                                                {
                                                    Report.Diagnosis_Start_Date = (string.IsNullOrEmpty(tmp_str) == false) ? tmp_str : "-";
                                                }

                                                tmp_str = dfi.Workbook.Diagnosis_End_Date;

                                                if (tmp_str.Equals("-") == true)
                                                {
                                                    Report.Diagnosis_End_Date = ((string.IsNullOrEmpty(diag_eday) == false) && (diag_eday.Equals("-") == false)) ? diag_eday : tmp_str;
                                                }
                                                else
                                                {
                                                    Report.Diagnosis_End_Date = (string.IsNullOrEmpty(tmp_str) == false) ? tmp_str : "-";
                                                }

                                                tmp_str = dfi.Workbook.Parts_Level1;

                                                if (tmp_str.Equals("-") == true)
                                                {
                                                    Report.Parts_Level1 = ((string.IsNullOrEmpty(part_lv1) == false) && (part_lv1.Equals("-") == false)) ? part_lv1 : tmp_str;
                                                }
                                                else
                                                {
                                                    Report.Parts_Level1 = (string.IsNullOrEmpty(tmp_str) == false) ? tmp_str : "-";
                                                }

                                                tmp_str = dfi.Workbook.Parts_Level2;

                                                if (tmp_str.Equals("-") == true)
                                                {
                                                    Report.Parts_Level2 = ((string.IsNullOrEmpty(part_lv2) == false) && (part_lv2.Equals("-") == false)) ? part_lv2 : tmp_str;
                                                }
                                                else
                                                {
                                                    Report.Parts_Level2 = (string.IsNullOrEmpty(tmp_str) == false) ? tmp_str : "-";
                                                }

                                                tmp_str = dfi.Workbook.Facility_Grade == null ? "-" : dfi.Workbook.Facility_Grade;

                                                if (tmp_str.Equals("-") == true)
                                                {
                                                    Report.Facility_Grade = ((string.IsNullOrEmpty(fac_grade) == false) && (fac_grade.Equals("-") == false)) ? fac_grade : tmp_str;
                                                }
                                                else
                                                {
                                                    Report.Facility_Grade = (string.IsNullOrEmpty(tmp_str) == false) ? tmp_str : "-";
                                                }

                                                tmp_str = dfi.Workbook.Facility_Defect == null ? "-" : dfi.Workbook.Facility_Defect;

                                                if (tmp_str.Equals("-") == true)
                                                {
                                                    Report.Facility_Defect = ((string.IsNullOrEmpty(fac_defect) == false) && (fac_defect.Equals("-") == false)) ? fac_defect : tmp_str;
                                                }
                                                else
                                                {
                                                    Report.Facility_Defect = (string.IsNullOrEmpty(tmp_str) == false) ? tmp_str : "-";
                                                }
                                                #endregion

                                                for (int j = 3; j < 13; j++)
                                                {
                                                    if ((raw_data[i, j] != null) && (raw_data[i, j].ToString().Equals("0") == false) && (raw_data[i, j].ToString().Equals("-") == false))
                                                    {
                                                        Report.Parts_Level3 = raw_data[i, 1] == null ? "-" : raw_data[i, 1].ToString();
                                                        Report.Parts_Level4 = raw_data[i, 2] == null ? "-" : raw_data[i, 2].ToString();
                                                        Report.Parts_Level5 = "-";
                                                        Report.Parts_Level6 = "-";
                                                        Report.Performance_Improve = "-";
                                                        Report.Parts_Grade = raw_data[i, 15] == null ? "-" : raw_data[i, 15].ToString();
                                                        Report.Parts_Defect = raw_data[i, 14] == null ? "-" : raw_data[i, 14].ToString();
                                                        Report.Damage_Type = raw_data[2, j] == null ? "-" : raw_data[2, j].ToString();
                                                        Report.Damage_Points = raw_data[i, j] == null ? "-" : raw_data[i, j].ToString();
                                                        Report.Damage_Picture = "-";
                                                        Report.Maintenance_Plan = "-";
                                                        Report.Maintenance_Method = "-";
                                                        Report.Maintenance_Quantity = "-";
                                                        Report.Maintenance_Quantity_Unit = "-";
                                                        Report.Maintenance_Unit_Price = "-";
                                                        Report.Maintenance_Cost = "-";
                                                        Report.Remarks = raw_data[i, 16] == null ? "-" : raw_data[i, 16].ToString();

                                                        Reports.Add(Report);
                                                    }
                                                }
                                            }
                                        }
                                        #endregion
                                    }
                                    else if (si.Processing.Equals("B") == true)
                                    {
                                        #region [ # Processing - Grade / Type B ]
                                        List<Data_Index> indexes = Search_Index("G", si);

                                        for (int i = Convert.ToInt32(si.Data_Index); i < (row + 1); i++)
                                        {
                                            bool grant = false;

                                            if ((raw_data[i, 1] != null) || (raw_data[i, 4] != null))
                                            {
                                                string subject = raw_data[i, 1] == null ? string.Empty : raw_data[i, 1].ToString();

                                                if (string.IsNullOrEmpty(subject) == true)
                                                {
                                                    subject = raw_data[i, 4] == null ? string.Empty : raw_data[i, 4].ToString();

                                                    if (string.IsNullOrEmpty(subject) == false)
                                                    {
                                                        grant = true;
                                                    }
                                                }
                                                else
                                                {
                                                    if (subject.Contains("평균") == false)
                                                    {
                                                        grant = true;
                                                    }
                                                    else
                                                    {
                                                        break;
                                                    }
                                                }
                                            }

                                            if (grant == true)
                                            {
                                                Report_Data Report = new Report_Data();
                                                Report.Facility_Number = fac_number;
                                                Report.Facility_Name = fac_name;
                                                Report.Manage_Number = manage_num;

                                                #region [ # Facility Information Checking - From ex Liet Processing ]
                                                string tmp_str = dfi.Workbook.Completion_Date;

                                                if (tmp_str.Equals("-") == true)
                                                {
                                                    Report.Completion_Date = ((string.IsNullOrEmpty(completion_day) == false) && (completion_day.Equals("-") == false)) ? completion_day : tmp_str;
                                                }
                                                else
                                                {
                                                    Report.Completion_Date = (string.IsNullOrEmpty(tmp_str) == false) ? tmp_str : "-";
                                                }

                                                tmp_str = dfi.Workbook.Facility_Address;

                                                if (tmp_str.Equals("-") == true)
                                                {
                                                    Report.Facility_Address = ((string.IsNullOrEmpty(fac_address) == false) && (fac_address.Equals("-") == false)) ? fac_address : tmp_str;
                                                }
                                                else
                                                {
                                                    Report.Facility_Address = (string.IsNullOrEmpty(tmp_str) == false) ? tmp_str : "-";
                                                }

                                                tmp_str = dfi.Workbook.Facility_Type;

                                                if (tmp_str.Equals("-") == true)
                                                {
                                                    Report.Facility_Type = ((string.IsNullOrEmpty(fac_type) == false) && (fac_type.Equals("-") == false)) ? fac_type : tmp_str;
                                                }
                                                else
                                                {
                                                    Report.Facility_Type = (string.IsNullOrEmpty(tmp_str) == false) ? tmp_str : "-";
                                                }

                                                tmp_str = dfi.Workbook.Diagnosis_Type;

                                                if (tmp_str.Equals("-") == true)
                                                {
                                                    Report.Diagnosis_Type = ((string.IsNullOrEmpty(diag_type) == false) && (diag_type.Equals("-") == false)) ? diag_type : tmp_str;
                                                }
                                                else
                                                {
                                                    Report.Diagnosis_Type = (string.IsNullOrEmpty(tmp_str) == false) ? tmp_str : "-";
                                                }

                                                tmp_str = dfi.Workbook.Diagnosis_Company;

                                                if (tmp_str.Equals("-") == true)
                                                {
                                                    Report.Diagnosis_Company = ((string.IsNullOrEmpty(diag_company) == false) && (diag_company.Equals("-") == false)) ? diag_company : tmp_str;
                                                }
                                                else
                                                {
                                                    Report.Diagnosis_Company = (string.IsNullOrEmpty(tmp_str) == false) ? tmp_str : "-";
                                                }

                                                tmp_str = dfi.Workbook.Diagnosis_Price;

                                                if (tmp_str.Equals("-") == true)
                                                {
                                                    Report.Diagnosis_Price = ((string.IsNullOrEmpty(diag_cost) == false) && (diag_cost.Equals("-") == false)) ? diag_cost : tmp_str;
                                                }
                                                else
                                                {
                                                    Report.Diagnosis_Price = (string.IsNullOrEmpty(tmp_str) == false) ? tmp_str : "-";
                                                }

                                                tmp_str = dfi.Workbook.Diagnosis_Start_Date;

                                                if (tmp_str.Equals("-") == true)
                                                {
                                                    Report.Diagnosis_Start_Date = ((string.IsNullOrEmpty(diag_sday) == false) && (diag_sday.Equals("-") == false)) ? diag_sday : tmp_str;
                                                }
                                                else
                                                {
                                                    Report.Diagnosis_Start_Date = (string.IsNullOrEmpty(tmp_str) == false) ? tmp_str : "-";
                                                }

                                                tmp_str = dfi.Workbook.Diagnosis_End_Date;

                                                if (tmp_str.Equals("-") == true)
                                                {
                                                    Report.Diagnosis_End_Date = ((string.IsNullOrEmpty(diag_eday) == false) && (diag_eday.Equals("-") == false)) ? diag_eday : tmp_str;
                                                }
                                                else
                                                {
                                                    Report.Diagnosis_End_Date = (string.IsNullOrEmpty(tmp_str) == false) ? tmp_str : "-";
                                                }

                                                tmp_str = dfi.Workbook.Parts_Level1;

                                                if (tmp_str.Equals("-") == true)
                                                {
                                                    Report.Parts_Level1 = ((string.IsNullOrEmpty(part_lv1) == false) && (part_lv1.Equals("-") == false)) ? part_lv1 : tmp_str;
                                                }
                                                else
                                                {
                                                    Report.Parts_Level1 = (string.IsNullOrEmpty(tmp_str) == false) ? tmp_str : "-";
                                                }

                                                tmp_str = dfi.Workbook.Parts_Level2;

                                                if (tmp_str.Equals("-") == true)
                                                {
                                                    Report.Parts_Level2 = ((string.IsNullOrEmpty(part_lv2) == false) && (part_lv2.Equals("-") == false)) ? part_lv2 : tmp_str;
                                                }
                                                else
                                                {
                                                    Report.Parts_Level2 = (string.IsNullOrEmpty(tmp_str) == false) ? tmp_str : "-";
                                                }

                                                tmp_str = dfi.Workbook.Facility_Grade == null ? "-" : dfi.Workbook.Facility_Grade;

                                                if (tmp_str.Equals("-") == true)
                                                {
                                                    Report.Facility_Grade = ((string.IsNullOrEmpty(fac_grade) == false) && (fac_grade.Equals("-") == false)) ? fac_grade : tmp_str;
                                                }
                                                else
                                                {
                                                    Report.Facility_Grade = (string.IsNullOrEmpty(tmp_str) == false) ? tmp_str : "-";
                                                }

                                                tmp_str = dfi.Workbook.Facility_Defect == null ? "-" : dfi.Workbook.Facility_Defect;

                                                if (tmp_str.Equals("-") == true)
                                                {
                                                    Report.Facility_Defect = ((string.IsNullOrEmpty(fac_defect) == false) && (fac_defect.Equals("-") == false)) ? fac_defect : tmp_str;
                                                }
                                                else
                                                {
                                                    Report.Facility_Defect = (string.IsNullOrEmpty(tmp_str) == false) ? tmp_str : "-";
                                                }
                                                #endregion

                                                List<string> Items = new List<string>();
                                                Items.Add(Report.Parts_Level3);
                                                Items.Add(Report.Parts_Level4);
                                                Items.Add(Report.Parts_Level5);
                                                Items.Add(Report.Parts_Level6);
                                                Items.Add(Report.Performance_Improve);
                                                Items.Add(Report.Parts_Grade);
                                                Items.Add(Report.Parts_Defect);
                                                Items.Add(Report.Damage_Type);
                                                Items.Add(Report.Damage_Points);
                                                Items.Add(Report.Damage_Picture);
                                                Items.Add(Report.Maintenance_Plan);
                                                Items.Add(Report.Maintenance_Method);
                                                Items.Add(Report.Maintenance_Quantity);
                                                Items.Add(Report.Maintenance_Quantity_Unit);
                                                Items.Add(Report.Maintenance_Unit_Price);
                                                Items.Add(Report.Maintenance_Cost);
                                                Items.Add(Report.Remarks);

                                                object value = null;

                                                for (int j = 0; j < Items.Count; j++)
                                                {
                                                    value = null;

                                                    if ((j != 5) && (j != 7) && (j != 8))
                                                    {
                                                        int cnt = 0;

                                                        foreach (List<int> tcol in indexes[j].col)
                                                        {
                                                            foreach (int inner in tcol)
                                                            {
                                                                if (value == null)
                                                                {
                                                                    value = raw_data[i, inner] == null ? null : raw_data[i, inner].ToString();
                                                                }
                                                                else
                                                                {
                                                                    if (inner == 3)
                                                                    {
                                                                        value += value != null ? "~" : null;
                                                                    }

                                                                    value += raw_data[i, inner] == null ? "" : raw_data[i, inner].ToString();
                                                                }
                                                            }

                                                            cnt++;

                                                            if (cnt < indexes[j].col.Count)
                                                            {
                                                                value += value != null ? " " : null;
                                                            }
                                                        }

                                                        string result = value == null ? "-" : value.ToString();

                                                        switch (j)
                                                        {
                                                            case 0: Report.Parts_Level3 = result; break;
                                                            case 1: Report.Parts_Level4 = result; break;
                                                            case 2: Report.Parts_Level5 = result; break;
                                                            case 3: Report.Parts_Level6 = result; break;
                                                            case 4: Report.Performance_Improve = result; break;
                                                            case 6: Report.Parts_Defect = result; break;
                                                            case 9: Report.Damage_Picture = result; break;
                                                            case 10: Report.Maintenance_Plan = result; break;
                                                            case 11: Report.Maintenance_Method = result; break;
                                                            case 12: Report.Maintenance_Quantity = result; break;
                                                            case 13: Report.Maintenance_Quantity_Unit = result; break;
                                                            case 14: Report.Maintenance_Unit_Price = result; break;
                                                            case 15: Report.Maintenance_Cost = result; break;
                                                            case 16: Report.Remarks = result; break;
                                                            default: break;
                                                        }
                                                    }
                                                }

                                                value = null;
                                                int[] columns;

                                                if (indexes[5].col.Count > 0)
                                                {
                                                    for (int k = 0; k < indexes[5].col.Count; k++)
                                                    {
                                                        columns = indexes[5].col[k].ToArray();

                                                        for (int j = 0; j < columns.Length; j++)
                                                        {
                                                            value = raw_data[i, columns[j]];
                                                            Report.Parts_Grade = value == null ? "-" : value.ToString();
                                                            value = null;

                                                            int pcol = indexes[8].col[k].ToArray()[j];
                                                            value = raw_data[i, pcol];

                                                            if ((value != null) && (value.ToString().Equals("-") == false) && (value.ToString().Equals("0") == false))
                                                            {
                                                                Report.Damage_Points = value == null ? "-" : value.ToString();
                                                                value = null;

                                                                for (int r = (indexes[7].row.Count - 1); r > -1; r--)
                                                                {
                                                                    bool crash = false;

                                                                    foreach (int tcol in indexes[7].row[r])
                                                                    {
                                                                        if (raw_data[tcol, pcol] != null)
                                                                        {
                                                                            value = raw_data[tcol, pcol];
                                                                            crash = true;
                                                                            break;
                                                                        }
                                                                    }

                                                                    if (crash == true)
                                                                    {
                                                                        break;
                                                                    }
                                                                }

                                                                Report.Damage_Type = value == null ? "-" : value.ToString().Replace("\n", " ");

                                                                Reports.Add(Report);
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                        #endregion
                                    }
                                    else if (si.Processing.Equals("-") == true)
                                    {
                                        #region [ # Processing - Grade / Type B : 시설물 등급, 결함 지수 ]
                                        fac_grade = si.Facility_Grade;
                                        fac_defect = si.Facility_Defect;

                                        int r = Convert.ToInt32(fac_grade.Substring(1));
                                        int c = Indexer[fac_grade.Substring(0, 1)];
                                        fac_grade = raw_data[r, c].ToString();

                                        r = Convert.ToInt32(fac_defect.Substring(1));
                                        c = Indexer[fac_defect.Substring(0, 1)];
                                        fac_defect = raw_data[r, c].ToString();
                                        #endregion
                                    }
                                }

                                if (roop_Mode == true)
                                {
                                    roop_Page++;
                                    sheet_name = "Page " + roop_Page;
                                }
                                else
                                {
                                    break;
                                }
                            }
                        }

                        if (dfi.Workbook.Processing.Equals("G") == true)
                        {
                            completion_day = string.Empty;
                            fac_address    = string.Empty;
                            fac_type       = string.Empty;
                            diag_type      = string.Empty;
                            diag_company   = string.Empty;
                            diag_cost      = string.Empty;
                            diag_sday      = string.Empty;
                            diag_eday      = string.Empty;
                            part_lv1       = string.Empty;
                            part_lv2       = string.Empty;
                            fac_grade      = string.Empty;
                            fac_defect     = string.Empty;
                        }

                        data_file.Save_Excel();
                        data_file.CloseExcel(); 

                        Thread.Sleep(3000);
                        
                        Report_Manager report_file = new Report_Manager();
                        report_file.Init_Excel_Report(@"" + m_txb_path_TuReport.Text + @"\" + dfl.Report_Name, "점검진단정보");
                        
                        if (Reports.Count > 0)
                        {
                            DCnts.AppendLine(dfi.Workbook.File_Name + " : " + Reports.Count);
                            Writing_Report(report_file, Reports);
                        }

                        report_file.Save_Excel();
                        report_file.CloseExcel();
                    }

                    done++;

                    SetLabelText(labelX10, dfl.Report_Name + " (" + done + " / " + dfl.Files.Count + ")");
                    SetLabelText(labelX8, dfi.Workbook.File_Name);
                }

                endT = DateTime.Now;
                SetLabelText(labelX9, "Process Time : " + endT.Subtract(startT).TotalSeconds + " sec");

                Report_Manager liquidate = new Report_Manager();
                liquidate.Init_Excel_Report(@"" + m_txb_path_TuReport.Text + @"\" + dfl.Report_Name, "점검진단정보");
                liquidate.Remove_Sheet("샘플");
                liquidate.Change_Worksheet("점검진단정보");
                liquidate.Save_Excel();
                liquidate.CloseExcel();

                DCnts.AppendLine();
                FileManager.LogWriter(DCnts.ToString(), CommonBase.LogPath, "Checking", false, false, false, false, true);
                DCnts.Clear();
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="name"></param>
        /// <returns></returns>
        private Facility_Info Find_Facility(string name)
        {
            Facility_Info res = new Facility_Info();
            res.Facility_Name = "-";
            res.Facility_Num = "-";

            string[] sub = name.Split(new string[] { " " }, StringSplitOptions.RemoveEmptyEntries);
            sub = sub[1].Split(new string[] { "-", "_" }, StringSplitOptions.RemoveEmptyEntries);

            string s_name = sub[0];
            string e_name = sub[1];

            foreach (Facility_Info fi in Facilities)
            {
                if ((fi.Facility_Name.Contains(s_name) == true) && (fi.Facility_Name.Contains(e_name)))
                {
                    res = fi;
                }
            }

            return res;
        }

        public struct Post_Row_Proc
        {
            public bool is_row;
            public int ck_row;
        }

        private bool is_row = false;

        private List<Post_Row_Proc> PostRows = new List<Post_Row_Proc>();
        
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        private List<Data_Index> Search_Index(string WB, Sheet_Info si)
        {
            List<Data_Index> Data_Indexes = new List<Data_Index>();

            List<string> Items = new List<string>();
            Items.Add(si.Parts_Level3);
            Items.Add(si.Parts_Level4);
            Items.Add(si.Parts_Level5);
            Items.Add(si.Parts_Level6);
            Items.Add(si.Performance_Improve);
            Items.Add(si.Parts_Grade);
            Items.Add(si.Parts_Defect);
            Items.Add(si.Damage_Type);
            Items.Add(si.Damage_Points);
            Items.Add(si.Damage_Picture);
            Items.Add(si.Maintenance_Plan);
            Items.Add(si.Maintenance_Method);
            Items.Add(si.Maintenance_Quantity);
            Items.Add(si.Maintenance_Quantity_Unit);
            Items.Add(si.Maintenance_Unit_Price);
            Items.Add(si.Maintenance_Cost);
            Items.Add(si.Remarks);

            foreach (string item in Items)
            {
                if (item.Equals("-") == false)
                {
                    if (item.Contains("/") == true)
                    {
                        Data_Indexes.Add(Proc_Index_Slash(item, Convert.ToInt32(si.Data_Index)));

                        if (is_row == true)
                        {
                            Post_Row_Proc prp = new Post_Row_Proc();
                            prp.is_row = true;
                            prp.ck_row = Data_Indexes.Count - 1;

                            is_row = false;
                        }
                    }
                    else if (item.Contains("~") == true)
                    {
                        int offset = 0;

                        if ((WB.Equals("G") == true) && (si.Processing.Equals("B") == true))
                        {
                            if ((Items.IndexOf(item) == 5) || (Items.IndexOf(item) == 8))
                            {
                                if ((Items[5].Contains("~") == true) && (Items[8].Contains("~") == true))
                                {
                                    string[] sub = Items[5].Split(new char[] { '~' }, StringSplitOptions.RemoveEmptyEntries);
                                    int s = Indexer[sub[0]];

                                    sub = Items[8].Split(new char[] { '~' }, StringSplitOptions.RemoveEmptyEntries);
                                    int e = Indexer[sub[0]];

                                    offset = Math.Abs(e - s);
                                }
                            }
                        }

                        Data_Indexes.Add(Proc_Index_Tild(item, Convert.ToInt32(si.Data_Index), offset));

                        if (is_row == true)
                        {
                            Post_Row_Proc prp = new Post_Row_Proc();
                            prp.is_row = true;
                            prp.ck_row = Data_Indexes.Count - 1;

                            PostRows.Add(prp);

                            is_row = false;
                        }
                    }
                    else
                    {
                        if (item.Contains("+") == true)
                        {
                            Data_Index new_DX = new Data_Index();
                            new_DX.row = new List<List<int>>();
                            new_DX.col = new List<List<int>>();

                            List<int> buff = new List<int>();
                            buff.Add(Convert.ToInt32(si.Data_Index));
                            new_DX.row.Add(buff);

                            new_DX.col.Add(Proc_Index_Plus(item));

                            Data_Indexes.Add(new_DX);
                        }
                        else
                        {
                            Data_Index new_DX = new Data_Index();
                            new_DX.row = new List<List<int>>();
                            new_DX.col = new List<List<int>>();

                            int tmp;

                            if (int.TryParse(item, out tmp) == false)
                            {
                                List<int> buff = new List<int>();
                                buff.Add(Indexer[item]);
                                new_DX.col.Add(buff);

                                buff = new List<int>();
                                buff.Add(Convert.ToInt32(si.Data_Index));
                                new_DX.row.Add(buff);
                            }
                            else
                            {
                                List<int> buff = new List<int>();
                                new_DX.col.Add(buff);

                                buff = new List<int>();
                                buff.Add(Convert.ToInt32(item));
                                new_DX.row.Add(buff);
                            }

                            Data_Indexes.Add(new_DX);
                        }
                    }
                }
                else
                {
                    Data_Index empty = new Data_Index();
                    empty.row = new List<List<int>>();
                    empty.col = new List<List<int>>();

                    Data_Indexes.Add(empty);
                }
            }

            foreach (Post_Row_Proc prp in PostRows)
            {
                if (prp.is_row == true)
                {
                    Data_Index tmp_one = new Data_Index();
                    tmp_one.row = Data_Indexes[prp.ck_row].row;
                    tmp_one.col = Data_Indexes[8].col;

                    Data_Indexes[prp.ck_row] = tmp_one;
                }
            }

            PostRows.Clear();

            return Data_Indexes;
        }

        private List<int> Proc_Index_Plus(string index)
        {
            string[] sub = index.Split(new char[] { '+' }, StringSplitOptions.RemoveEmptyEntries);
            List<int> idx = new List<int>();
            int tmp;

            foreach (string str in sub)
            {
                if (int.TryParse(str, out tmp) == false)
                {
                    idx.Add(Indexer[str.ToUpper()]);
                }
                else
                {
                    idx.Add(Convert.ToInt32(str));
                }
            }

            return idx;
        }

        private Data_Index Proc_Index_Tild(string index, int d_index, int offset)
        {
            Data_Index new_DX = new Data_Index();
            new_DX.row = new List<List<int>>();
            new_DX.col = new List<List<int>>();

            string[] sub = index.Split(new char[] { '~' }, StringSplitOptions.RemoveEmptyEntries);
            int tmp, start, end;

            if (int.TryParse(sub[0], out tmp) == false)
            {
                List<int> buff = new List<int>();
                buff.Add(d_index);
                new_DX.row.Add(buff);

                if (sub[0].Contains("+") == true)
                {
                    buff = Proc_Index_Plus(sub[0]);
                    new_DX.col.Add(buff);

                    start = buff[buff.Count - 1] + 1;
                    end   = Indexer[sub[1].ToUpper()];
                }
                else if (sub[1].Contains("+") == true)
                {
                    buff = Proc_Index_Plus(sub[1]);
                    new_DX.col.Add(buff);

                    start = Indexer[sub[0].ToUpper()];
                    end   = buff[0] - 1;

                }
                else
                {
                    start = Indexer[sub[0].ToUpper()];
                    end   = Indexer[sub[1].ToUpper()];
                }

                for (int i = start; i <= end; i += (1 + offset))
                {
                    buff = new List<int>();
                    buff.Add(i);
                    new_DX.col.Add(buff);
                }
            }
            else
            {
                List<int> buff = new List<int>();

                start = Convert.ToInt32(sub[0]);
                end = Convert.ToInt32(sub[1]);

                for (int i = start; i <= end; i++)
                {
                    buff = new List<int>();
                    buff.Add(i);
                    new_DX.row.Add(buff);
                }

                is_row = true;
            }

            return new_DX;
        }

        private Data_Index Proc_Index_Slash(string index, int d_index)
        {
            Data_Index new_DX = new Data_Index();
            new_DX.row = new List<List<int>>();
            new_DX.col = new List<List<int>>();

            string[] sub = index.Split(new char[] { '/' }, StringSplitOptions.RemoveEmptyEntries);
            int tmp;

            if (int.TryParse(sub[0], out tmp) == false)
            {
                List<int> buff = new List<int>();
                buff.Add(d_index);
                new_DX.row.Add(buff);

                if (sub[0].Contains("+") == true)
                {
                    buff = Proc_Index_Plus(sub[0]);
                    new_DX.col.Add(buff);

                    buff = new List<int>();
                    buff.Add(-1);
                    new_DX.col.Add(buff);

                    buff = new List<int>();
                    buff.Add(Indexer[sub[1].ToUpper()]);
                    new_DX.col.Add(buff);
                }
                else if (sub[1].Contains("+") == true)
                {
                    buff = new List<int>();
                    buff.Add(Indexer[sub[0].ToUpper()]);
                    new_DX.col.Add(buff);

                    buff = new List<int>();
                    buff.Add(-1);
                    new_DX.col.Add(buff);

                    buff = Proc_Index_Plus(sub[1]);
                    new_DX.col.Add(buff);
                }
                else
                {
                    buff = new List<int>();
                    buff.Add(Indexer[sub[0].ToUpper()]);
                    new_DX.col.Add(buff);

                    buff = new List<int>();
                    buff.Add(-1);
                    new_DX.col.Add(buff);

                    buff = new List<int>();
                    buff.Add(Indexer[sub[1].ToUpper()]);
                    new_DX.col.Add(buff);
                }
            }
            else
            {
                List<int> buff = new List<int>();

                buff = new List<int>();
                buff.Add(Convert.ToInt32(sub[0]));
                new_DX.row.Add(buff);

                buff = new List<int>();
                buff.Add(-1);
                new_DX.row.Add(buff);

                buff = new List<int>();
                buff.Add(Convert.ToInt32(sub[1]));
                new_DX.row.Add(buff);

                is_row = true;
            }

            return new_DX;
        }

        private void Gathering_Data(Sheet_Info si)
        {

        }

        private void Writing_Report(Report_Manager rm, List<Report_Data> Datas)
        {
            int idx = 2;
            string sheet_name = string.Empty;

            while (true)
            {
                sheet_name = "점검진단정보 (" + idx + ")";

                if (rm.Existing_Sheet(sheet_name) == false)
                {
                    break;
                }

                idx++;
            }

            idx--;
            sheet_name = "점검진단정보 (" + idx + ")";

            if (idx == 1)
            {
                rm.Change_Worksheet("점검진단정보");
            }
            else
            {
                rm.Change_Worksheet(sheet_name);
            }

            int s_idx = 0;

            while (true)
            {
                object tmp = rm.GetData(s_idx + 1, 1);

                if (tmp == null)
                {
                    break;
                }

                s_idx++;
            }

            int pages = 0;
            int index;
            int start = s_idx + 1;

            List<string> Data_Sets = new List<string>();

            for (int i = 0; i < Datas.Count; i++)
            {
                index = (s_idx + i) - (3000 * pages) + 1;

                if (index > 3000)
                {
                    try
                    {
                        rm.Change_Worksheet("샘플");

                        idx = 2;
                        sheet_name = string.Empty;

                        while (true)
                        {
                            sheet_name = "점검진단정보 (" + idx + ")";

                            if (rm.Existing_Sheet(sheet_name) == false)
                            {
                                break;
                            }

                            idx++;
                        }

                        rm.Copy_Worksheet(rm.exlWorkSheet, sheet_name);
                        rm.Change_Worksheet(sheet_name);
                        start = 2;

                        rm.Save_Excel();

                    }
                    catch (Exception exx)
                    {
                        string test = exx.Message;
                    }

                    pages++;

                    index = (s_idx + i) - (2999 * pages) + 1;
                }

                Data_Sets.Add(Datas[i].Facility_Number);
                Data_Sets.Add(Datas[i].Facility_Name);
                Data_Sets.Add(Datas[i].Manage_Number);
                Data_Sets.Add(Datas[i].Completion_Date);
                Data_Sets.Add(Datas[i].Facility_Address);
                Data_Sets.Add(Datas[i].Facility_Type);
                Data_Sets.Add(Datas[i].Diagnosis_Type);
                Data_Sets.Add(Datas[i].Diagnosis_Company);
                Data_Sets.Add(Datas[i].Diagnosis_Price);
                Data_Sets.Add(Datas[i].Diagnosis_Start_Date);
                Data_Sets.Add(Datas[i].Diagnosis_End_Date);
                Data_Sets.Add(Datas[i].Parts_Level1);
                Data_Sets.Add(Datas[i].Parts_Level2);
                Data_Sets.Add(Datas[i].Parts_Level3);
                Data_Sets.Add(Datas[i].Parts_Level4);
                Data_Sets.Add(Datas[i].Parts_Level5);
                Data_Sets.Add(Datas[i].Parts_Level6);
                Data_Sets.Add(Datas[i].Performance_Improve);
                Data_Sets.Add(Datas[i].Parts_Grade);
                Data_Sets.Add(Datas[i].Parts_Defect);
                Data_Sets.Add(Datas[i].Facility_Grade);
                Data_Sets.Add(Datas[i].Facility_Defect);
                Data_Sets.Add(Datas[i].Damage_Type);
                Data_Sets.Add(Datas[i].Damage_Points);
                Data_Sets.Add(Datas[i].Damage_Picture);
                Data_Sets.Add(Datas[i].Maintenance_Plan);
                Data_Sets.Add(Datas[i].Maintenance_Method);
                Data_Sets.Add(Datas[i].Maintenance_Quantity);
                Data_Sets.Add(Datas[i].Maintenance_Quantity_Unit);
                Data_Sets.Add(Datas[i].Maintenance_Unit_Price);
                Data_Sets.Add(Datas[i].Maintenance_Cost);
                Data_Sets.Add(Datas[i].Remarks);

                rm.InsertExcel("A" + index, Data_Sets.ToArray());

                Data_Sets.Clear();
            }

            rm.Save_Excel();
            
            //MessageBox.Show("완료");
        }
        #endregion
        #endregion

        private void buttonX1_Click(object sender, EventArgs e)
        {
            Load_FileInfos(@"F:\［ Download ］\sample.csv");
        }
    }
    ///================================================================================= End of Class : AceControl =///
}
